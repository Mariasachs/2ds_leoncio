// IF / ELSE -> ESTRUTURA CONDICIONAL PARA TOMADA DE DECISÃO 

const idade = 18;

if (idade >= 18) {
  console.log("Maior de idade");
}
else if (idade < 18) {
  console.log("Menor de idade");
}
else {
  console.log("Idade inválida");
}
// REFATORAÇÃO: Refazer com melhorias 
// IF, IF para IF / ELSE IF

// * escreva um código que pergunte qual a cor preferida. SE for vermelho, imprima "vermelho" se for azul, imprima "azul" , * SENÃO não conheço essa cor

// const = 'verde'
const cor = prompt('Qual a sua cor favorita')
if (cor === 'vermelho') {
  console.log('vermelho')
}
else if (cor == 'azul') {
  console.log('azul')
} else {
  console.log('Não conheço essa cor')
}
console.log(cor.length) // COMPRIMENTO DA STRING